import realmeBuds from "../assets/images/realmeairpode.jpeg";
import canoncamera from "../assets/images/CanonCamera.jpeg";

export const products = [
  {
    id: 1,
    product_name: "realme Techlife Buds T100 with 24hrs playback",
    rating: "4.5",
    reviews: 5832,
    price: 1999,
    original_price: 3499,
    category: "equipment",
    img: realmeBuds,
    logo: "img",

    offers: [
      "Special PriceGet extra ₹130 off (price inclusive of discount)T&C",

      "Combo OfferBuy 3-4 items save 5%;Buy 5 or more save 10%See all productsT&C",

      "Bank Offer5% Unlimited Cashback on Flipkart Axis Bank Credit CardT&C",

      "Bank Offer₹20 Off on first prepaid transaction using UPI payments, minimum order value ₹750/-T&C",
    ],
  },
  {
    id: 2,
    product_name: "Canon EOS M50 Mark Mirrorless Camera",
    rating: "4.4",
    reviews: 117,
    price: "57990",
    original_price: "66995",
    category: "electronics",
    img: canoncamera,
    logo: "img",

    offers: [
      "10% off on Citi Credit card EMI Transactions, upto 2000 an oredrs and Above T&C",

      "Combo OfferBuy 3-4 items save 5%;Buy 5 or more save 10%See all productsT&C",

      "Bank Offer5% Unlimited Cashback on Flipkart Axis Bank Credit CardT&C",

      "Bank Offer₹20 Off on first prepaid transaction using UPI payments, minimum order value ₹750/-T&C",
    ],
  },
];
